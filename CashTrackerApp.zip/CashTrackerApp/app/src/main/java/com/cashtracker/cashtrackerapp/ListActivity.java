package com.cashtracker.cashtrackerapp;

import android.os.Bundle;
import android.os.StrictMode;
import android.support.v7.app.ActionBarActivity;
import android.util.Log;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;

import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.util.EntityUtils;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Created by viktor on 1/10/16.
 */
public class ListActivity extends ActionBarActivity {
    JsonObject jsonObject = new JsonObject();
    Gson gson = new Gson();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list);
        if (android.os.Build.VERSION.SDK_INT > 9) {
            StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
            StrictMode.setThreadPolicy(policy);
        }

        final HttpClient httpclient = new DefaultHttpClient();
        final HttpPost httppost = new HttpPost("http://188.166.9.31:80/app_cashtracker/payments/");

        try {

            List<NameValuePair> nameValuePairs = new ArrayList<>(2);
            nameValuePairs.add(new BasicNameValuePair("mobile", "1"));
            nameValuePairs.add(new BasicNameValuePair("user_id", Globals.id));
            httppost.setEntity(new UrlEncodedFormEntity(nameValuePairs));

            //Execute HTTP Post Request
            HttpResponse httpResponse = httpclient.execute(httppost);
            String response = EntityUtils.toString(httpResponse.getEntity());


            jsonObject = gson.fromJson(response, JsonObject.class);


            //Log.v("TESTTTT", jsonPayments.toString());

            List<String> payments = new ArrayList<String>();

            for (Map.Entry<String, JsonElement> entry : jsonObject.entrySet()) {
                String result = entry.getValue().toString().replaceAll("[\",{,}]", "");
                result = result.replaceAll(":", "\\ ");
                result = result.replaceAll("Category", "\\ Category:");
                result = result.replaceAll("Value", "\\ Value:");
                result = result.replaceAll("Date", "\\ Date:");
                result = result.replaceAll("@", ":");
                payments.add(result);
           /* JsonArray array = entry.getValue().getAsJsonObject().getAsJsonArray("unterfeld");
            for (JsonElement codeHolder : array) {
                codes.add(codeHolder.getAsJsonObject().getAsJsonPrimitive("code").getAsInt());
            }*/
            }

            ArrayAdapter adapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, payments);
            ListView lvPreview =  (ListView) findViewById(R.id.lvPayments);
            lvPreview.setAdapter(adapter);

        } catch (ClientProtocolException e) {
            //TODO Auto-generated catch block
        } catch (IOException e) {
            //TODO Auto-generated catch block
        }

    }
}