package com.cashtracker.cashtrackerapp;

import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.os.StrictMode;
import android.support.v7.app.ActionBarActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.google.gson.Gson;
import com.google.gson.JsonObject;

import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.util.EntityUtils;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class LoginActivity extends ActionBarActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        if (android.os.Build.VERSION.SDK_INT > 9) {
            StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
            StrictMode.setThreadPolicy(policy);
        }

        Button btnLogin = (Button) findViewById(R.id.btnLogin);
        btnLogin.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                // Create a new HttpClient and Post Header
                HttpClient httpclient = new DefaultHttpClient();
                HttpPost httppost = new HttpPost("http://188.166.9.31:80/app_cashtracker/login_action/");
                EditText txtUsername = (EditText) findViewById(R.id.txtUsername);
                String username = String.valueOf(txtUsername.getText());
                EditText txtPassword = (EditText) findViewById(R.id.txtPassword);
                String password = String.valueOf(txtPassword.getText());

               try {

                    List<NameValuePair> nameValuePairs = new ArrayList<>(3);
                   nameValuePairs.add(new BasicNameValuePair("mobile", "1"));
                    nameValuePairs.add(new BasicNameValuePair("email", username));
                    nameValuePairs.add(new BasicNameValuePair("password", password));
                    httppost.setEntity(new UrlEncodedFormEntity(nameValuePairs));

                    //Execute HTTP Post Request
                   HttpResponse httpResponse = httpclient.execute(httppost);
                   String response = EntityUtils.toString(httpResponse.getEntity());
                   Gson gson = new Gson();
                   JsonObject jsonObject = gson.fromJson(response, JsonObject.class);

                     if(jsonObject.get("error").toString().equals("false")) {
                        Globals.id = jsonObject.get("user_id").toString();
                         Intent i = new Intent(getApplicationContext(), MainActivity.class);
                         startActivity(i);
                    }else{
                         new AlertDialog.Builder(LoginActivity.this)
                                 .setTitle("Error")
                                 .setMessage("Wrong username or password!")
                                 .setIcon(android.R.drawable.ic_dialog_alert)
                                 .show();
                     }
                } catch (ClientProtocolException e) {
                    //TODO Auto-generated catch block
                } catch (IOException e) {
                    //TODO Auto-generated catch block
                }
            }
        });

    }
}
