package com.cashtracker.cashtrackerapp;

import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.os.StrictMode;
import android.support.v7.app.ActionBarActivity;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;

import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;

import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.util.EntityUtils;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

/**
 * Created by viktor on 1/10/16.
 */
public class MainActivity extends ActionBarActivity {
    JsonObject jsonObject = new JsonObject();
    Gson gson = new Gson();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        if (android.os.Build.VERSION.SDK_INT > 9) {
            StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
            StrictMode.setThreadPolicy(policy);
        }

        final HttpClient httpclient = new DefaultHttpClient();
        final HttpPost httppost = new HttpPost("http://188.166.9.31:80/app_cashtracker/home/");

        try {

            List<NameValuePair> nameValuePairs = new ArrayList<>(3);
            nameValuePairs.add(new BasicNameValuePair("mobile", "1"));
            nameValuePairs.add(new BasicNameValuePair("user_id", Globals.id));
            httppost.setEntity(new UrlEncodedFormEntity(nameValuePairs));

            //Execute HTTP Post Request
            HttpResponse httpResponse = httpclient.execute(httppost);
            String response = EntityUtils.toString(httpResponse.getEntity());


            jsonObject = gson.fromJson(response, JsonObject.class);




        } catch (ClientProtocolException e) {
            //TODO Auto-generated catch block
        } catch (IOException e) {
            //TODO Auto-generated catch block
        }
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        String currentDateandTime = sdf.format(new Date());

        final EditText txtDate = (EditText) findViewById(R.id.txtDate);
        txtDate.setText(currentDateandTime);
        final EditText txtAmount = (EditText) findViewById(R.id.txtAmount);
        txtAmount.setText("0.00");
        final Spinner spinCurrency = (Spinner) findViewById(R.id.spinCurrency);
        List<String> currencies = new ArrayList<String>();
        currencies.add("BGN");
        currencies.add("USD");
        currencies.add("EUR");
        currencies.add("GBP");
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_dropdown_item, currencies);
        spinCurrency.setAdapter(adapter);
        final Spinner spinCategory = (Spinner) findViewById(R.id.spinCategory);
        List<String> categories = new ArrayList<String>();
        final List<String> categoriesId = new ArrayList<String>();
        JsonObject jsonCategories = gson.fromJson(jsonObject.get("categories"), JsonObject.class);

        Log.v("TESTTTT", jsonCategories.toString());



        for (Map.Entry<String, JsonElement> entry : jsonCategories.entrySet()) {
            String result = entry.getValue().toString().replaceAll("[\"]", "");
            categories.add(result);

            String key = entry.getKey();
            categoriesId.add(key);


           /* JsonArray array = entry.getValue().getAsJsonObject().getAsJsonArray("unterfeld");
            for (JsonElement codeHolder : array) {
                codes.add(codeHolder.getAsJsonObject().getAsJsonPrimitive("code").getAsInt());
            }*/
        }
        adapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_dropdown_item, categories);
        spinCategory.setAdapter(adapter);

        Button btnAdd = (Button) findViewById(R.id.btnAdd);
        btnAdd.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
    try

    {
        HttpClient httpclient = new DefaultHttpClient();
        HttpPost httppost = new HttpPost("http://188.166.9.31:80/app_cashtracker/add_payment/");
        String date = txtDate.getText().toString();

        List<NameValuePair> nameValuePairs = new ArrayList<>(6);
        nameValuePairs.add(new BasicNameValuePair("mobile", "1"));
        nameValuePairs.add(new BasicNameValuePair("user_id", Globals.id));
        nameValuePairs.add(new BasicNameValuePair("date_time", date));
        nameValuePairs.add(new BasicNameValuePair("value", txtAmount.getText().toString()));
        nameValuePairs.add(new BasicNameValuePair("currency", spinCurrency.getSelectedItem().toString()));
        nameValuePairs.add(new BasicNameValuePair("category", categoriesId.get(spinCategory.getSelectedItemPosition())));
        httppost.setEntity(new UrlEncodedFormEntity(nameValuePairs));

        //Execute HTTP Post Request
        HttpResponse httpResponse = httpclient.execute(httppost);
        String response = EntityUtils.toString(httpResponse.getEntity());

        Gson gson = new Gson();
        JsonObject jsonObject = gson.fromJson(response, JsonObject.class);

        if(jsonObject.get("success").toString().equals("1")) {
            new AlertDialog.Builder(MainActivity.this)
                    .setTitle("Success")
                    .setMessage("Payment added successfully!")
                    .setIcon(android.R.drawable.ic_dialog_alert)
                    .show();

        }else{
            new AlertDialog.Builder(MainActivity.this)
                    .setTitle("Error")
                    .setMessage("Wrong input data! Please, recheck.")
                    .setIcon(android.R.drawable.ic_dialog_alert)
                    .show();
        }



    }

    catch(
    ClientProtocolException e
    )

    {
        //TODO Auto-generated catch block
    }

    catch(IOException e){

    }
            }
        });

        Button btnView = (Button) findViewById(R.id.btnView);
        btnView.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                Intent i = new Intent(getApplicationContext(), ListActivity.class);
                startActivity(i);
            }
            });
}
}
