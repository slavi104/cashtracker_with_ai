package com.cashtracker.cashtrackerapp;

/**
 * Created by viktor on 1/10/16.
 */
public class Globals {
    public static String id;
}

